var searchData=
[
  ['delivery_0',['delivery',['../classmodels_1_1order_1_1_order.html#a74715f5f2350a5d1fde5de461206a7b9',1,'models::order::Order']]]
];
