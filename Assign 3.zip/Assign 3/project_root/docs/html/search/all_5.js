var searchData=
[
  ['generatecustomerreport_0',['generateCustomerReport',['../classmodels_1_1report_1_1_report.html#a225caa69b2fb2aae440d3653645007a3',1,'models::report::Report']]],
  ['generateitempopularityreport_1',['generateItemPopularityReport',['../classmodels_1_1report_1_1_report.html#a0e3d178d5e2b5adf9d45600dc44bb7c9',1,'models::report::Report']]],
  ['generatesalesreport_2',['generateSalesReport',['../classmodels_1_1report_1_1_report.html#a6e37454f8bee1a0b0b57a99d0c1da2d9',1,'models::report::Report']]],
  ['getavailablequantity_3',['getAvailableQuantity',['../classmodels_1_1item_1_1_vegetable.html#af2983c952f10b4501f2264bea2b97939',1,'models::item::Vegetable']]],
  ['getboxdetails_4',['getBoxDetails',['../classmodels_1_1item_1_1_premade_box.html#a4df349c9fec9dba1d79f319a33d2d6d5',1,'models::item::PremadeBox']]],
  ['getdiscount_5',['getDiscount',['../classmodels_1_1customer_1_1_corporate_customer.html#a2772a5b3ee438e619f1ec63e9223cf66',1,'models::customer::CorporateCustomer']]],
  ['getorderid_6',['getOrderId',['../classmodels_1_1order_1_1_order.html#a9617b78d4874619e78fa1da2272c0684',1,'models::order::Order']]],
  ['getprice_7',['getPrice',['../classmodels_1_1item_1_1_item.html#a398de4a431eede17b06d5a596481ee9b',1,'models::item::Item']]],
  ['gettotalcost_8',['getTotalCost',['../classmodels_1_1order_1_1_order.html#a6aa3ef7e3da2e821953643705a7b3467',1,'models::order::Order']]]
];
