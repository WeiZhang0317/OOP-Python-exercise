var searchData=
[
  ['firstname_0',['firstName',['../classmodels_1_1customer_1_1_customer.html#addbe0b73d6b42b279d2cce9703d8f11c',1,'models::customer::Customer']]]
];
