var searchData=
[
  ['quantity_0',['quantity',['../classmodels_1_1item_1_1_item.html#a857609e832bd49ab15d28ab877588673',1,'models::item::Item']]]
];
