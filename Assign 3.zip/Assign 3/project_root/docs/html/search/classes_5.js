var searchData=
[
  ['vegetable_0',['Vegetable',['../classmodels_1_1item_1_1_vegetable.html',1,'models::item']]]
];
