var searchData=
[
  ['size_0',['size',['../classmodels_1_1item_1_1_premade_box.html#a658e550075a498b29fdbe3166f30ce97',1,'models::item::PremadeBox']]]
];
