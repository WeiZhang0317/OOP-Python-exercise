var searchData=
[
  ['fullname_0',['fullName',['../classmodels_1_1customer_1_1_customer.html#a07476e515c3e36c688b3f860db52be86',1,'models::customer::Customer']]]
];
