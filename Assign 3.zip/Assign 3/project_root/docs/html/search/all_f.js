var searchData=
[
  ['unit_5ftype_0',['unit_type',['../classmodels_1_1item_1_1_item.html#afc807671e3cbb5bbc2ef55f5da200ba2',1,'models::item::Item']]]
];
