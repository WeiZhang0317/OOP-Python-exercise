from tkinter import *

root = Tk()  #create the main window
root.mainloop() #runs the main event loop