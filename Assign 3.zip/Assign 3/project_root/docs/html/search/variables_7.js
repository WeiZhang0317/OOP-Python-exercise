var searchData=
[
  ['orderhistory_0',['orderHistory',['../classmodels_1_1customer_1_1_customer.html#a34d56c4585cdf0775308aa9843f60895',1,'models::customer::Customer']]]
];
