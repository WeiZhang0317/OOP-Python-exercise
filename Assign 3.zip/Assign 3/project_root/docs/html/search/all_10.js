var searchData=
[
  ['vegetable_0',['Vegetable',['../classmodels_1_1item_1_1_vegetable.html',1,'models::item']]],
  ['viewbalance_1',['viewBalance',['../classmodels_1_1customer_1_1_customer.html#ad49c1dee830192f50d3e55bebbf5a22b',1,'models::customer::Customer']]],
  ['vieworderhistory_2',['viewOrderHistory',['../classmodels_1_1customer_1_1_customer.html#a21cfd7d42b9235a3033693d607d0abba',1,'models::customer::Customer']]]
];
