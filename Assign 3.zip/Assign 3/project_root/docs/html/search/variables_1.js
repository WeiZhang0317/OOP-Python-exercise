var searchData=
[
  ['category_0',['category',['../classmodels_1_1item_1_1_item.html#a397028911b8b6887599ab2dc60a17334',1,'models::item::Item']]],
  ['customer_1',['customer',['../classmodels_1_1order_1_1_order.html#a25a4c78afc1a4f752d5ffc64b5dca420',1,'models::order::Order']]],
  ['customitems_2',['customItems',['../classmodels_1_1item_1_1_premade_box.html#a892d53dc54bdce1cc352ad02113beb47',1,'models::item::PremadeBox']]]
];
