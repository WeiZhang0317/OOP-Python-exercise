var searchData=
[
  ['viewbalance_0',['viewBalance',['../classmodels_1_1customer_1_1_customer.html#ad49c1dee830192f50d3e55bebbf5a22b',1,'models::customer::Customer']]],
  ['vieworderhistory_1',['viewOrderHistory',['../classmodels_1_1customer_1_1_customer.html#a21cfd7d42b9235a3033693d607d0abba',1,'models::customer::Customer']]]
];
