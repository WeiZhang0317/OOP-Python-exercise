var searchData=
[
  ['name_0',['name',['../classmodels_1_1item_1_1_item.html#ab0c971f86921a3c35de2ea2415071158',1,'models::item::Item']]]
];
