var searchData=
[
  ['items_0',['items',['../classmodels_1_1order_1_1_order.html#a0ebec9ac9b4e69f992ea3e97a366b0c3',1,'models::order::Order']]]
];
